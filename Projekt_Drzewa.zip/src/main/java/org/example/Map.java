package org.example;

public class Map {
    Drzewo[][] mapa;

    Map(int n) {
        mapa = new Drzewo[n][n];
    }

    public Drzewo[][] zwrocmape() {
        return mapa;
    }

    public void dodajDrzewo(int x, int y, Drzewo drzewo) {
        mapa[x][y] = drzewo;
    }
}
