package org.example;

public class Jemiola {
    int x;
    int y;
    String closest;
    int ile;
    public Jemiola(int x, int y, String closest, int ile, double range) {
        this.x = x;
        this.y = y;
        this.closest = closest;
        this.ile = ile;
    }
}
