package org.example;

public interface Spread {
    void Spread(int X, int Y, Map map);
}
