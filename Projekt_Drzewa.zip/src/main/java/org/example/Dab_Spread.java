package org.example;

public class Dab_Spread implements Spread {

    @Override
    public void Spread(int x, int y, Map mapa) {
        Drzewo[][] map = mapa.zwrocmape();
        int n = map.length;

        int[] dx = { 0, 1, 1, 1, 0, -1, -1, -1 };
        int[] dy = { 1, 1, 0, -1, -1, -1, 0, 1 };

        for (int i = 0; i < dx.length; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];
            if (newX >= 0 && newX < n && newY >= 0 && newY < n) {
                if (map[newY][newX] == null) {
                    Dab dab = new Dab(newX, newY, 0, 0, false);
                    mapa.dodajDrzewo(newX, newY, dab);
                    break;
                }
            }
        }
    }
}
