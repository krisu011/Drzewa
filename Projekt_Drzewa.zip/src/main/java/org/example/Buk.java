package org.example;

public class Buk {
}
